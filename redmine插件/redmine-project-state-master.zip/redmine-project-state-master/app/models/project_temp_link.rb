class ProjectTempLink < ActiveRecord::Base
end
