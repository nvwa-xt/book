resources :projects do
  put 'easy_mindmup_update_layout', to: 'easy_mindmup#update_layout', as: 'easy_mindmup_update_layout'
end
