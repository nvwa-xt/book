require File.dirname(__FILE__) + '/../test_helper'

class AccessingArticlesTest < ActionController::IntegrationTest
  def setup
    assert true
  end
  
  test "access an article with access defined by the whitelist" do
    assert true
  end
end