module ApplicationHelper

end