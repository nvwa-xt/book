# encoding: utf-8
get 'my_roadmaps', :to => 'my_roadmaps#index'
post 'my_roadmaps', :to => 'my_roadmaps#index'
