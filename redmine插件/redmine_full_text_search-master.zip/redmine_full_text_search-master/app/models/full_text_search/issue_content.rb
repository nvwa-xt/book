module FullTextSearch
  class IssueContent < ActiveRecord::Base
  end
end
